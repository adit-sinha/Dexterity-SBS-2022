1) You must have tkinter, pillow, urllib3 and mysql connector modules installed
2) Create a database 'dex' and run 'sqlLoader.py'
3)run 'mainpage.py' in Login interface